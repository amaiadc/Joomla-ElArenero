<?php die("Access Denied"); ?>#x#a:2:{s:6:"output";s:0:"";s:6:"result";a:5:{i:0;O:8:"stdClass":3:{s:4:"link";s:101:"http://virtuemart.net/news/latest-news/468-virtuemart-3-0-6-with-completely-redesigned-multi-variants";s:5:"title";s:60:"VirtueMart 3.0.6 with completely redesigned 'Multi Variants'";s:11:"description";s:3170:"<div><p>In VirtueMart 3.0.6 we fine tuned the completely redesigned <strong><em>Multi Variants</em></strong> which were introduced in our previous release. Let me give you a short introduction.</p>
<p>One of the most advanced feature of an ecommerce store is the possibility to display different variants of one product in a clear structure. The typical example are the T-Shirt product variants. We have created a small example here: <a href="http://demo.virtuemart.net/default-products/vm-t-shirt-multi-variant-detail">http://demo.virtuemart.net/default-products/vm-t-shirt-multi-variant-detail</a>.</p>
<p>Not all colours are available for any size and due to aesthetic reasons the "blue" imprints are not available for the "blue" coloured T-Shirt. Any drop-down combination points to a real product. The handling is easy as most important product attributes are accessible from the parent product (variant attributes, Sku, price). So you can easily configure more than 50 product variants in a single view, with different stock levels, price and images. If you select an already existing attribute like length, weight, etc, then you can change the value directly using the drop-down matrix in the parent product. You can also modify the display (for example rounding).</p>
<p><img src="http://virtuemart.net/images/virtuemart/news/childvariantsmatrix.PNG" alt="Variant Matrix" title="Variant Matrix" class="caption" width="692" height="196" /></p>
<p>We added a new configurable automatically selected shipment and payment if more than one is available. Also the long desired feature "register as admin in the frontend" got added.&nbsp;We also cleaned up the Custom Fields tab in the Product Edit view to give more room for Custom Field configurations. VirtueMart 3.0.6 is also&nbsp;a lot faster, due to new mysql keys and more caching. The administration menu is now still usable while being collapsed.</p>
<p>There is a new keepAlive script, which automatically extends the session for your shoppers if there is a product in the cart. It also automatically extends the session lifetime in all backend views. It is checking for input, so it is not running endlessly. As an example, if your session time is set to 30 minutes and your guest is checking out, leaving the computer (with open browser) and returning after 50 minutes, he is still logged in. If the user is now interacting with the screen (clicking, typing), then the keepAlive scripts directly fires a keepAlive and extends the session again. Lets assume the user stores his data after 70 minutes (searching for his/her credit card), the session is still alive. <br /><br /></p>
<p>We strongly recommend anyone using an older version of VM3 to update. The release is heavily tested and some changes and fixes were done especially for 3rd party developers.</p>
<div>
<p><a href="http://virtuemart.net/download">DOWNLOAD VM3 NOW<br /> VirtueMart 3 component (core and AIO)</a></p>
</div>
<p>There is also a small update for vm2.6 series. There are also new keys for the sql joins to speed up your store. Also the new js handler got added for easier compatibility between vm2.6 andd vm3 extensions.</p></div>";}i:1;O:8:"stdClass":3:{s:4:"link";s:70:"http://virtuemart.net/news/latest-news/467-release-of-virtuemart-3-0-4";s:5:"title";s:27:"Release of VirtueMart 3.0.4";s:11:"description";s:2954:"<div><p>A bit earlier than expected, we have to release vm3.0.4 to close a vulnerability in the core. This is a real vulnerability, no exploit. The problem is a wrong error report setting, which can reveal the used server path for the real attack.</p>
<p>More and more people use php5.4 or php5.5, which has another default error handling and so they sometimes displayed Strict Errors (revealing the path). To prevent this, we added a function to disable the "Strict Standards" reporting for the "default" and "none" setting in Joomla. Unluckily, we left for a special debugging case the setting on enabled. So regardless the used configuration setting, you always got at least the "Simple" setting. Luckily it is not so easy to create warnings and errors in VirtueMart 3.</p>
<p>In case you don't want to update, here is the manual fix:</p>
<ol>
<li>open the file config.php at /administrator/components/com_virtuemart/helpers/config.php.</li>
<li>Go to line 583 and replace <br />ini_set('display_errors', '1');<br /> with<br /> ini_set('display_errors', '0');</li>
</ol>
<p>Or just download the new version.</p>
<p>The layout changes of the new version are just one important one for people who override the sublayout prices. The sublayout prices.php had a &lt;div class="clear"&gt;&lt;/div&gt; at the end, which got removed to increase the flexibility of the sublayout.</p>
<p>The new version contains a new sample product, the "child variant", which allows you to use up to 5 dropdowns to determine the product variant. It is similar to the stockable plugin, but allows also changing the variant data of any child directly from the parent. The handling of the feature is not perfect yet, but a good start. Feel free to share your ideas on our forum.</p>
<p>New features and bug fixes:</p>
<ul>
<li>cleaning of the code</li>
<li>increased robustness</li>
<li>increased consistency</li>
<li>more j3 compatibility (minors)</li>
</ul>
<ul>
<li>added js to fire automatically the checkout (without redirect) to show directly confirm</li>
<li>link to manufacturer on the productdetail page calls the manufacturer, not any longer the product list of the manufacturer</li>
<li>the rss feed in the controlpanel is now loaded by ajax, to prevent that the controlpanel isn't loaded if rss has problems</li>
<li>custom media, related products and categories with image size parameter</li>
</ul>
<ul>
<li>added var to vmview "writeJs", for example to prevent writing of js in pdfs</li>
<li>added hash for categoryListTree</li>
<li>changed calculator so, that default userfield parameters are better directly set if instantiated. Less problems with tax by country for guests</li>
<li>fixed in vmplugin.php the function declarePluginParams</li>
<li>fixed trigger plgVmDeclarePluginParamsUserfieldVM3</li>
</ul>
<p>and some more.</p>
<div>
<p><a href="http://virtuemart.net/download">DOWNLOAD VM3 NOW<br /> VirtueMart 3 component (core and AIO)</a></p>
</div></div>";}i:2;O:8:"stdClass":3:{s:4:"link";s:105:"http://virtuemart.net/news/latest-news/466-klik-pay-is-included-in-virtuemart-2-6-14-and-virtuemart-3-0-2";s:5:"title";s:68:"Klik &amp; Pay is included in VirtueMart 2.6.14 and VirtueMart 3.0.2";s:11:"description";s:4302:"<div><p>We are pleased to announce the release of VirtueMart 2.6.14 and VirtueMart 3.0.2.</p>
<p><img src="http://virtuemart.net/images/klikandpay/klikandpay-logo.png" alt="Klik&amp;Pay included in VirtueMart" style="margin-left: 5px; margin-bottom: 5px; float: right;" />Klik &amp; Pay is a holistic secured payment solution accessible via PC, tablets and/or smartphone. Partners with many Banks and International acquirers, Klik &amp; Pay assists its merchants for 15 years, in France, Europe and all over the World. Klik &amp; Pay is:</p>
<ul>
	<li>A global solution not requiring a DSA</li>
	<li>A competitive pricing, without monthly fees nor set-up fee</li>
	<li>An anti-fraud scoring linked to an account with or without 3D Secure</li>
	<li>A multi-lingual staff available by telephone and email</li>
	<li>A consulting service to help you to develop your business and assist you at an International level</li>
</ul>
<p>Optimize your conversion rate:</p>
<ul>
	<li>Multi currencies cashing</li>
	<li>Multi lingual payment pages</li>
	<li>3DS and non 3 DS merchant account with trigger point</li>
</ul>
<p>Increase Sales:</p>
<ul>
	<li>Virtual Payment Terminal</li>
	<li>Payment by email</li>
	<li>Payment by SMS</li>
</ul>
<p>Secure your activity:</p>
<ul>
	<li>Anti-fraud scoring system</li>
	<li>Transaction Management</li>
	<li>Litigation support</li>
</ul>
<p>&nbsp;<a href="https://www.klikandpay.com/cgi-bin/inscription.pl?L=en">Open an account</a>&nbsp;or send us an email to <a href="mailto:market@klikandpay.com">market@klikandpay.com </a>
</p>
<p>If you already have a Klik &amp; Pay merchant account, you can directly set it up using our payment plugin Klik &amp; Pay provided in VirtueMart.</p>
<p><img src="http://virtuemart.net/images/klikandpay/klikandpay-snapshot.png" alt="klikandpay screenshot" style="display: block; margin-left: auto; margin-right: auto;" />
</p>
<p>We worked a lot on the new Virtuemart 3.0.2 . The update should be easy. There will be a lot database changes, but they are many, but minor. It will increase the speed of your page noticeable. Bugs fixed:</p>
<ul>
	<li>increased consistency of the install.sql and reduced int size for better performance</li>
	<li>extra attachment should now be sent to the shopper and not vendor as intended</li>
	<li>added itemId to products</li>
	<li>fixed "typo" in calculationh.php</li>
	<li>vmJsApi the function addJScript is not anylonger overwriting the attribute "written" if exists already</li>
	<li>set CacheTime to minutes</li>
	<li>fixed javascript for tinyMce 4, removed the doubled // of the flag link</li>
	<li>fixed typo in plugin.php</li>
	<li>Better use of loading the xml parameter into the JForm (thx Kainhofer)</li>
	<li>enhanced modals (thx Spyros)</li>
	<li>sortSearchListQuery or products model uses getCurrentUser now to ensure that the correct id is set (Thank you Stan Scholtz)</li>
	<li>removed a lot deprecated getSetError(s)</li>
	<li>vmTable is not derived anylonger from JTable, derived functions added</li>
	<li>optimised joomla tables for fullinstaller</li>
	<li>Some more adjustments of VmTable for J3, using dummy interfaces</li>
	<li>fixed spec file font problem, if no spec files there</li>
	<li>users allowed to adminstrate shoppers can now also select shoppers in the cart</li>
	<li>removed old comments, vmdebugs,...</li>
	<li>changed all &lt;span class="product-field-display"&gt; to &lt;div class="product-field-display"&gt;</li>
</ul>
<div>
	<p><a href="http://dev.virtuemart.net/attachments/download/887/com_virtuemart.3.0.2_extract_first.zip">DOWNLOAD VM3 NOW<br /> VirtueMart 3 component (core and AIO)</a>
	</p>
</div>
<p>We still support vm2.6 and there is also no EOL set yet. But new features will be found in VM3. The update to vm2.6.14 should be very user friendly. Bugs fixed:</p>
<ul>
	<li>jQuery fix for automatically redirection to payment providers</li>
	<li>PDF works with diskcache now, less problems with images in invoice</li>
	<li>Authorize.net works now also with extra ST address</li>
	<li>small fixes, enhancements, removed typos for different payments</li>
</ul>
<div>
	<p><a href="http://dev.virtuemart.net/attachments/download/879/com_virtuemart.2.6.14_extract_first.zip">DOWNLOAD VM2.6.14<br /> VirtueMart 2 component (core and AIO)</a>
	</p>
</div></div>";}i:3;O:8:"stdClass":3:{s:4:"link";s:63:"http://virtuemart.net/news/latest-news/465-virtuemart-3-is-here";s:5:"title";s:47:"VirtueMart 3 continues to set global benchmarks";s:11:"description";s:9443:"<div><p>Compatible with Joomla 2.5 and Joomla 3, the new generation of the eCommerce solution VirtueMart is now available with many new easing features. Built with the experience of more than 10 years VirtueMart 3 provides you with a powerful and comprehensive eCommerce solution. We give you a flavour of the work we have done to provide you with one of the best open-source e-commerce solution around!</p>
<p>This new generation of the ecommerce platform VirtueMart includes many new features under the hood and is a continuous development of VM2. Our main focus was to make it compatible with Joomla 3, cleaning the architecture, increasing the stability, and increasing the performance. In short: looking superficially at VirtueMart 3 it looks and works almost as VM2, but the feeling and handling is different.</p>
<p>Thousands of man hours have been spent and countless changes have been done updating and enhancing VirtueMart. We are happy and thank the many dedicated developers and store owners that helped to test and provide positive feedback on this most recent version.</p>
<p>VM2 to VM3 is an upgrade, implemented using the Joomla install manager - it does not require a migration (as was the case for VM1 to VM2). We have maintained as much compatibility as possible with VM2 but we have had to make some changes in order to deliver the improvements in VM3.</p>
<div>
<p><a href="http://dev.virtuemart.net/attachments/download/875/VirtueMart3.0.0_Joomla_2.5.27-Stable-Full_Package.zip">DOWNLOAD NOW <br />Full installer includes Joomla 2.5 with VirtueMart 3 installed</a></p>
</div>
<h3>Your Shoppers and Store Owners benefits</h3>
<p>Shoppers will be delighted by the enhanced speed, add to cart buttons in the category browse view, and simpler checkout. Shop owners will notice the enhanced backend speed and simplified customfields. Shop builders will find a lot more tools to fulfill the wishes of their customers.</p>
<p>The ajaxified reload of product variants and neighboured products enhance the browsing experience significantly. To ensure proper loading of JavaScript we had to implement our own Javascript loader. We may extend this feature also to other views for example the pagination of the product browse page.</p>
<p>New internal program caches reduce the sql queries for the most used tasks by more than 25%. Heavy functions are additional cached with the Joomla cache.</p>
<h3>Developers benefits</h3>
<p>The new core has an advanced cart with enhancements to provide better update compatibility. For example the new custom userfields include now an option to be displayed on the checkout page and can use their own overridable mini layouts, making it easy to adjust the cart to legal requirements without touching the template. The data stored in the session is minified, which can be easily modified by plugins (for example to adjust the weight). The cart is automatically stored for registered users. The cart checks also for any reload of the available quantity of the items and corrects it if needed.</p>
<p>You can re-use your layouts by using the new sublayouts (like minilayouts). They give your store a consistent appearance and make it easier to adjust standards for different layouts in one overridable file. The input data is very unified which makes it stable against updates. This is very handy for the native "add to cart" button and customfields in the category browse view. New parameters in the Joomla menu settings for virtuemart views and modules provide more flexibility and better joomla integration.</p>
<p>Frontend managing combined with the Joomla ACL now allows your vendors to directly access the VirtueMart backend from the frontend, without having access to the Joomla backend. The system now provides different modes for different multivendor systems. VM3 is now prepared to work with a sales team, or shipment team.</p>
<p>We reduced the dependencies on Joomla, but increased on the other hand the integration. For example, the core now uses only the JFormFields of Joomla 2.5 and not any longer the old vmParameter, but we added vRequest (MIT) as choice for JInput. Developers can now use the normal JFormField joomla conventions for all plugins.</p>
<h3>Customfields refined</h3>
<p>With new options, redesigned and a lot more flexible to use. In VM2 you had to override none or all customfields of the parent. In VirtueMart 3 you can disable or override each customfield independent of the others. This makes creation of product variants a lot easier and faster. The new child variants gives the possibility to display products with up to 5 rambifications (can be increased), which depend on each other. Very important is also the new behaviour that you can use one customtype as often you want for one product.</p>
<p>"Additional Shoppergroup" is a new feature for shoppergroups, which does not replace the default groups. This is very handy if you use the default shoppergroups for calculation.</p>
<h3>jQuery clearance</h3>
<p>The new jQuery versions are now mainly the same as in Joomla 3.3 (jQuery v1.11.0,jQuery UI - v1.9.2, legacy complete). Shops using Joomla 2.5 with VirtueMart 3 also benefit from this. It prevents needless configuration problems.</p>
<h3>Extensions ready for VM3</h3>
<p>All changes in the API have been deeply tested and most 3rd party developers have updated their extensions already. The whole core and extensions are now working with the new abstraction layer (vmText, vRequest,...). Please visit <a href="http://extensions.virtuemart.net">http://extensions.virtuemart.net</a> for updates of your extensions.</p>
<p><img src="http://virtuemart.net/images/virtuemart/news/virtuemart3.png" alt="" style="float: right;" /></p>
<h3>Customer experience</h3>
<p>Will benefit from a smoother shopping experience:</p>
<ul>
<li>Improved page load speeds</li>
<li>The ability to add products and their variants to the cart directly from the category browse view</li>
<li>Simpler checkout process helping to reduce cart abandonment</li>
<li>Predicted shipping costs prior to full address entry</li>
<li>Cart contents for logged in users are stored to allow checkout at a later time</li>
<li>For multi lingual stores, we now have a language fallback to the default language for non-translated text</li>
</ul>
<h3>Merchants and Shop Builders</h3>
<p>Will see significant improvements, such as:</p>
<ul>
<li>The most advanced VM available to date</li>
<li>Increased backend performance</li>
<li>Simplified process for adding and implementing product customfields</li>
<li>Enhanced parameters for displaying related products and categories</li>
<li>Additional parameters for the views in the joomla menu configuration</li>
<li>Easily add and configure your own shopperfields directly useable in the shopping cart</li>
<li>Increased ability to Restrict/Manage employee access to key functions using ACL</li>
</ul>
<h3>Template developers</h3>
<ul>
<li>Easily maintain a consistent appearance across multiple views using new Sub-layouts</li>
<li>Improved CSS gives a starting point for use in responsive designs</li>
</ul>
<h3>Create your market place</h3>
<ul>
<li>Different modes for multivendor</li>
<li>Full front end administration</li>
</ul>
<h3>Enhancements from a technical perspective</h3>
<p>The team's significant points of focus were:-</p>
<ul>
<li>Compatibility with Joomla 3</li>
<li>Clean architectural structure</li>
<li>Increased stability</li>
<li>Increased performance both for the front and backend</li>
<li>New internal program caches reduce the sql queries for the most used tasks by more than 25%</li>
<li>Reduced dependency on Joomla where appropriate.</li>
</ul>
<h3>Developers</h3>
<ul>
<li>Uses only the JFormFields</li>
<li>Reduced jQuery conflicts as we now mainly implement the same as Joomla 3.4 (jQuery v1.11.0,jQuery UI - v1.9.2, legacy complete).</li>
<li>Core and extensions are now working with a new abstraction layer</li>
<li>The xml files have also been updated to J2.5 style</li>
<li>New JavaScript Handler for ajaxified product details reload</li>
</ul>
<h3>How to update</h3>
<p>Do NOT upgrade straight into live - you should run upgrades on a test version of your store and thoroughly test BEFORE considering a live upgrade</p>
<p>Please read <a href="http://docs.virtuemart.net/tutorials/installation-migration-upgrade/198-upgrade-virtuemart-2-to-virtuemart-3.html">http://docs.virtuemart.net/tutorials/installation-migration-upgrade/198-upgrade-virtuemart-2-to-virtuemart-3.html</a> for additional information.</p>
<div>
<p><a href="http://dev.virtuemart.net/attachments/download/874/com_virtuemart.3.0.0_extract_first.zip">DOWNLOAD VM3 NOW<br /> VirtueMart 3 component (core and AIO)</a></p>
</div>
<h3>Some useful tutorials for templaters and developers</h3>
<p>Are available on our documentation center:</p>
<ul>
<li><a href="http://docs.virtuemart.net/tutorials/development/175-code-adjustments-for-virtuemart-3.html">Code adjustments for VirtueMart 3</a></li>
<li><a href="http://docs.virtuemart.net/tutorials/templating-layouts/199-sublayouts.html">VM Sublayouts</a></li>
<li><a href="http://docs.virtuemart.net/tutorials/development/196-the-vm-javascript-handler.html">VM Javascript Handler</a></li>
</ul>
<h3>Support the project</h3>
<p>If you like what we do, consider supporting us with a <a href="http://extensions.virtuemart.net/support/virtuemart-supporter-membership-detail">Membership</a>.</p></div>";}i:4;O:8:"stdClass":3:{s:4:"link";s:93:"http://virtuemart.net/news/latest-news/464-virtuemart-2-6-12-is-released-special-realex-offer";s:5:"title";s:51:"VirtueMart 2.6.12 is released, Special Realex offer";s:11:"description";s:4384:"<div><p>We are pleased to announce the release of VirtueMart 2.6.12</p>
<div>
<p><a href="http://virtuemart.net//downloads">Download VirtueMart 2.6.12</a></p>
</div>
<h2>Special Realex Offer</h2>
<p>Realex Payments, one of Europe’s fastest growing payment solution providers, is delighted with its latest integration with Virtuemart, the free online shop solution. The integration with Virtuemart provides ecommerce merchants with a one-stop solution for merchant online payment processing. To mark this latest release, Realex Payments are offering 2 months FREE payment processing to all new VirtueMart merchants to their platform.</p>
<p>Improve your online conversions with Realex Payments’ latest shopping cart integration with VirtueMart.</p>
<div><img class="align-left" src="http://virtuemart.net//images/virtuemart/news/realex.png" alt="VirtueMart 2.6.12 includes Realex" />
<div>
<p>Realex Payments are offering 2 months FREE payment processing to all new VirtueMart merchants to their platform.</p>
<a href="http://www.realexpayments.com/partner-referral?id=virtuemart">Sign Up today</a></div>
</div>
<h2>VirtueMart 3 almost ready to launch</h2>
<p>We release VirtueMart 3 next week.</p>
<p>You have not tested yet? it is time to do it.</p>
<p>You think you found a bug? please report it on the <a href="http://forum.virtuemart.net/index.php?board=136.0">forum</a>.</p>
<p>Your are a 3rd party VirtueMart developer? Test your extension against the new version.</p>
<div>
<p><a href="http://dev.virtuemart.net/attachments/download/831/com_virtuemart.2.9.9.2_extract_first.zip">Download the RC version of VirtueMart 3</a></p>
</div>
<h2>Updates and bug fixes VirtueMart 2.6.12</h2>
<ul>
<li><span>Category tree cache considers language now</span></li>
<li><span>Realex: handling503; incorrect eci being submitted when card type is mastercard and eci value returned is 2;returntovm: missing option com_virtuemart; 503 dont block transactions; invalid payment infos errorcode 509;&nbsp;maestro cards, redirect in case of payment details error; added partial refund and partial capture</span></li>
<li><span>Klarna: ok with opc off; country names; company/private fixed</span></li>
<li><span>Vmpdf uses folder <span>VMPATH_ROOT&nbsp;</span>instead of K_PATH_IMAGES</span></li>
<li><span>Encrypted data is stored encrypted in vmtable cache</span></li>
<li><span>Installation routine shows right options for fullinstaller</span></li>
<li><span>VmTable, enhanced Cache and other optimisations</span></li>
<li><span>Payments autosubmit jquery</span></li>
<li><span>Added VMPATH_ROOT constants for compatibility with VM3</span></li>
<li><span>Fixed recipient in invoice/view.html.php rendermaillayout</span></li>
<li><span>Controller alias vmplg</span></li>
<li><span>AIO: removed permission checking, list installed plugins</span></li>
<li><span>Unpublished the uk states</span></li>
<li>Permissions use joomla and/or virtuemart</li>
<li><span>Storemanagers can edit orders now (as requested)</span></li>
<li><span>Removed "displayed name" from order edit address</span></li>
<li><span>Loadvmtemplatestyle should now always load the fe style even fired from BE</span></li>
<li><span>Preloading js</span></li>
<li><span>Enhanced Registration email added address,</span></li>
<li><span>Fixed typo in config/checkout</span></li>
<li><span>Vmtable: added bindto</span></li>
<li><span>_getlayoutpath: checks if layout is in plugin folder and then plugin subfolder</span></li>
<li><span>Access to update tools does not use issupervendor function anylonger</span></li>
<li><span>Fixed error in shoppergroup list, that ordering for ids deleted the "default" shoppergroup&nbsp;</span></li>
<li><span>Added order status list for desired attachment order status&nbsp;</span></li>
<li><span>Readded to continue_link_html the class in the link class="continue continue_link"</span></li>
<li><span>Added attachment for mail. Use attach_os as array in the config file for the desired orderstatus&nbsp;</span></li>
<li><span>Added option reuseorders, also settable by config file.</span></li>
<li><span>Minor in userfields load function</span></li>
<li><span>Payments using json_encode</span></li>
<li><span>Shopper group name in payment/shipment</span></li>
<li><span>Just added the filter for the dot again (slug creation)</span></li>
<li><span>Joomla update server fix</span></li>
</ul></div>";}}}